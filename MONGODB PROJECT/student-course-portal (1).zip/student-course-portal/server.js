const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/studentportal')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));

// === MODELS ===

// Course Model
const courseSchema = new mongoose.Schema({
  title: String,
  instructor: String,
  credits: Number,
});
const Course = mongoose.model('Course', courseSchema);

// User Model
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
});
const User = mongoose.model('User', userSchema);

// === ROUTES ===

// Register Route
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    // Check if user already exists
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ msg: 'User already exists' });

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save user
    const user = new User({ name, email, password: hashedPassword });
    await user.save();

    res.status(201).json({ msg: 'User registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Registration failed' });
  }
});

// Login Route
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid email or password' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Invalid email or password' });

    // Generate token
    const token = jwt.sign({ userId: user._id }, 'secret123', { expiresIn: '1h' });

    res.json({ token, user: { name: user.name, email: user.email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Login failed' });
  }
});

// Get All Courses
app.get('/api/courses', async (req, res) => {
  const courses = await Course.find();
  res.json(courses);
});

// Create Course
app.post('/api/courses', async (req, res) => {
  const { title, instructor, credits } = req.body;
  const course = new Course({ title, instructor, credits });
  await course.save();
  res.status(201).json(course);
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


// Update Course
app.put('/api/courses/:id', async (req, res) => {
  const { id } = req.params;
  const { title, instructor, credits } = req.body;

  try {
    const updated = await Course.findByIdAndUpdate(
      id,
      { title, instructor, credits },
      { new: true }
    );

    if (!updated) return res.status(404).json({ msg: 'Course not found' });

    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Update failed' });
  }
});

// Delete Course
app.delete('/api/courses/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const deleted = await Course.findByIdAndDelete(id);

    if (!deleted) return res.status(404).json({ msg: 'Course not found' });

    res.json({ msg: 'Course deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Deletion failed' });
  }
});
